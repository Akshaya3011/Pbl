package PBL;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BindingOctoperf {
	
	public static String URL = "https://petstore.octoperf.com";

	public static WebDriver driver;
	
	@Given("Login in JPetStore Application")
	public void login_in_j_pet_store_application() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(URL);
	  
	}

	@When("I Click on the Enter the Store")
	public void i_click_on_the_enter_the_store() {
		
		driver.findElement(By.xpath("//a[text()='Enter the Store']")).click();
	    
	}

	@Then("Enter the SignIn Option")
	public void enter_the_sign_in_option() {
		
		driver.findElement(By.xpath("//a[text()='Sign In']")).click();
	    
	}

	@Then("Enter the Username {string}")
	public void enter_the_username(String string) {
	    
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(string);
	    
	}
	
	
	@Then("Enter the Password {string}")
	public void enter_the_password_j2ee(String string) {
	  
	
		driver.findElement(By.xpath("//input[@name='password']")).clear();

		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(string);
		
		
	    
	}
	
	

	@Then("I clicked on Login button")
	public void i_clicked_on_login_button() {
		
		driver.findElement(By.xpath("//input[@name='signon']")).click();
	   
	}

	@Then("I Logged In Successfully")
	public void i_logged_in_successfully() {
		
		String welcome_content=driver.findElement(By.xpath("//a[text()='Sign Out']")).getText();

		String Expected_welcome_content="Sign Out";

		assertEquals(welcome_content, Expected_welcome_content);

		System.out.println("Login successfully");
	   
	}

	@Then("I closed the Application")
	public void i_closed_the_application() {
		
		driver.quit();
	    
	}




}
